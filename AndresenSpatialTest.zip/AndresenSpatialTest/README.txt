This is an implementation of Martin Andresen's point-pattern test algorithm.

The test has been published here: http://dx.doi.org/10.1016/j.apgeog.2008.12.004

To run the program use the file 'run.bat'.

I've included some shapefiles which can be used to test the program, they're in
the 'data' directory.

The program is licenced under the GNU General Public Licence (v3) (see licence.txt).